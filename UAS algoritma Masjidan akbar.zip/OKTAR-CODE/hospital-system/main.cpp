#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <unordered_map>
#include <stack>
#include <vector>
#include <algorithm>
#include <cctype>
#include <iomanip>
#include <ctime>

using namespace std;

// Struktur data untuk menyimpan informasi pasien
struct Patient {
    string id;
    string name;
    int age;
    string diagnosis;
    string admissionDate; // Format: YYYY-MM-DD
    string phoneNumber;
    string address;
};

// Node untuk Single Linked List
struct Node {
    Patient data;
    Node* next;
    
    Node(Patient p) : data(p), next(nullptr) {}
};

// Struktur untuk undo operation
struct DeletedNode {
    Patient data;
    int position;
};

// Class untuk Single Linked List dengan fitur tambahan
class HospitalSystem {
private:
    Node* head;
    unordered_map<string, Node*> hashTable; // Hash table untuk pencarian cepat
    stack<DeletedNode> undoStack; // Stack untuk undo delete
    int nodeCount;

    // Helper function: Convert string to lowercase
    string toLower(string str) {
        transform(str.begin(), str.end(), str.begin(), ::tolower);
        return str;
    }

    // Helper function: Trim whitespace
    string trim(const string& str) {
        size_t first = str.find_first_not_of(" \t\r\n");
        if (first == string::npos) return "";
        size_t last = str.find_last_not_of(" \t\r\n");
        return str.substr(first, (last - first + 1));
    }

public:
    HospitalSystem() : head(nullptr), nodeCount(0) {}

    // Destructor
    ~HospitalSystem() {
        clearAll();
    }

    // 1. Insert at Beginning
    Node* insertAtBeginning(Patient p) {
        Node* newNode = new Node(p);
        if (!newNode) {
            cout << "Memory allocation failed!" << endl;
            return nullptr;
        }
        
        newNode->next = head;
        head = newNode;
        hashTable[p.id] = newNode;
        nodeCount++;
        
        cout << "Patient " << p.name << " (ID: " << p.id << ") added at beginning." << endl;
        return newNode;
    }

    // 2. Insert at End
    Node* insertAtEnd(Patient p) {
        Node* newNode = new Node(p);
        if (!newNode) {
            cout << "Memory allocation failed!" << endl;
            return nullptr;
        }

        if (head == nullptr) {
            head = newNode;
        } else {
            Node* temp = head;
            while (temp->next != nullptr) {
                temp = temp->next;
            }
            temp->next = newNode;
        }
        
        hashTable[p.id] = newNode;
        nodeCount++;
        
        cout << "Patient " << p.name << " (ID: " << p.id << ") added at end." << endl;
        return newNode;
    }

    // 3. Insert at Position
    bool insertAtPosition(Patient p, int position) {
        if (position < 0 || position > nodeCount) {
            cout << "Invalid position!" << endl;
            return false;
        }

        if (position == 0) {
            insertAtBeginning(p);
            return true;
        }

        Node* newNode = new Node(p);
        Node* temp = head;
        
        for (int i = 0; i < position - 1 && temp != nullptr; i++) {
            temp = temp->next;
        }

        if (temp == nullptr) {
            delete newNode;
            return false;
        }

        newNode->next = temp->next;
        temp->next = newNode;
        hashTable[p.id] = newNode;
        nodeCount++;
        
        cout << "Patient " << p.name << " inserted at position " << position << endl;
        return true;
    }

    // 4. Delete from Beginning
    bool deleteFromBeginning() {
        if (head == nullptr) {
            cout << "List is empty!" << endl;
            return false;
        }

        Node* temp = head;
        DeletedNode deleted;
        deleted.data = temp->data;
        deleted.position = 0;
        undoStack.push(deleted);

        head = head->next;
        hashTable.erase(temp->data.id);
        
        cout << "Patient " << temp->data.name << " (ID: " << temp->data.id << ") deleted from beginning." << endl;
        delete temp;
        nodeCount--;
        return true;
    }

    // 5. Delete from End
    bool deleteFromEnd() {
        if (head == nullptr) {
            cout << "List is empty!" << endl;
            return false;
        }

        if (head->next == nullptr) {
            DeletedNode deleted;
            deleted.data = head->data;
            deleted.position = 0;
            undoStack.push(deleted);
            
            hashTable.erase(head->data.id);
            cout << "Patient " << head->data.name << " deleted from end." << endl;
            delete head;
            head = nullptr;
            nodeCount--;
            return true;
        }

        Node* temp = head;
        int pos = 0;
        while (temp->next->next != nullptr) {
            temp = temp->next;
            pos++;
        }

        DeletedNode deleted;
        deleted.data = temp->next->data;
        deleted.position = pos + 1;
        undoStack.push(deleted);

        Node* toDelete = temp->next;
        hashTable.erase(toDelete->data.id);
        cout << "Patient " << toDelete->data.name << " deleted from end." << endl;
        delete toDelete;
        temp->next = nullptr;
        nodeCount--;
        return true;
    }

    // 6. Delete by ID
    bool deleteByID(string id) {
        if (head == nullptr) {
            cout << "List is empty!" << endl;
            return false;
        }

        // Check if head is the target
        if (head->data.id == id) {
            DeletedNode deleted;
            deleted.data = head->data;
            deleted.position = 0;
            undoStack.push(deleted);

            Node* temp = head;
            head = head->next;
            hashTable.erase(id);
            cout << "Patient with ID " << id << " deleted." << endl;
            delete temp;
            nodeCount--;
            return true;
        }

        Node* prev = head;
        Node* curr = head->next;
        int pos = 1;

        while (curr != nullptr) {
            if (curr->data.id == id) {
                DeletedNode deleted;
                deleted.data = curr->data;
                deleted.position = pos;
                undoStack.push(deleted);

                prev->next = curr->next;
                hashTable.erase(id);
                cout << "Patient with ID " << id << " deleted." << endl;
                delete curr;
                nodeCount--;
                return true;
            }
            prev = curr;
            curr = curr->next;
            pos++;
        }

        cout << "Patient with ID " << id << " not found!" << endl;
        return false;
    }

    // 7. Search by ID (dengan hash table untuk O(1))
    Node* searchByID(string id) {
        // Try hash table first
        if (hashTable.find(id) != hashTable.end()) {
            return hashTable[id];
        }

        // Fallback to linear search
        Node* temp = head;
        while (temp != nullptr) {
            if (temp->data.id == id) {
                hashTable[id] = temp; // Update hash table
                return temp;
            }
            temp = temp->next;
        }

        return nullptr;
    }

    // 8. Search by Name (case-insensitive)
    vector<Node*> searchByName(string name) {
        vector<Node*> results;
        string searchName = toLower(name);
        
        Node* temp = head;
        while (temp != nullptr) {
            if (toLower(temp->data.name).find(searchName) != string::npos) {
                results.push_back(temp);
            }
            temp = temp->next;
        }

        return results;
    }

    // 9. Update Patient Data
    bool updatePatientData(string id, Patient newData) {
        Node* node = searchByID(id);
        if (node == nullptr) {
            cout << "Patient with ID " << id << " not found!" << endl;
            return false;
        }

        // If ID changes, update hash table
        if (node->data.id != newData.id) {
            hashTable.erase(node->data.id);
            hashTable[newData.id] = node;
        }

        node->data = newData;
        cout << "Patient data updated successfully!" << endl;
        return true;
    }

    // 10. Display All Patients
    void displayAll() {
        if (head == nullptr) {
            cout << "\nNo patients in the system." << endl;
            return;
        }

        cout << "\n" << string(130, '=') << endl;
        cout << left << setw(12) << "ID" 
             << setw(25) << "Name" 
             << setw(5) << "Age" 
             << setw(25) << "Diagnosis" 
             << setw(15) << "Admission" 
             << setw(15) << "Phone" << endl;
        cout << string(130, '=') << endl;

        Node* temp = head;
        int count = 0;
        while (temp != nullptr) {
            cout << left << setw(12) << temp->data.id
                 << setw(25) << temp->data.name
                 << setw(5) << temp->data.age
                 << setw(25) << temp->data.diagnosis
                 << setw(15) << temp->data.admissionDate
                 << setw(15) << temp->data.phoneNumber << endl;
            temp = temp->next;
            count++;
        }
        cout << string(130, '=') << endl;
        cout << "Total Patients: " << count << endl << endl;
    }

    // 11. Sort by Admission Date (Bubble Sort)
    void sortByDate() {
        if (head == nullptr || head->next == nullptr) {
            return;
        }

        bool swapped;
        do {
            swapped = false;
            Node* curr = head;

            while (curr->next != nullptr) {
                if (curr->data.admissionDate > curr->next->data.admissionDate) {
                    // Swap data
                    Patient temp = curr->data;
                    curr->data = curr->next->data;
                    curr->next->data = temp;

                    // Update hash table
                    hashTable[curr->data.id] = curr;
                    hashTable[curr->next->data.id] = curr->next;

                    swapped = true;
                }
                curr = curr->next;
            }
        } while (swapped);

        cout << "List sorted by admission date." << endl;
    }

    // 12. Reverse List
    void reverseList() {
        if (head == nullptr || head->next == nullptr) {
            return;
        }

        Node* prev = nullptr;
        Node* current = head;
        Node* next = nullptr;

        while (current != nullptr) {
            next = current->next;
            current->next = prev;
            prev = current;
            current = next;
        }

        head = prev;
        cout << "List reversed successfully." << endl;
    }

    // 13. Load from CSV
    int loadFromCSV(string filename) {
        ifstream file(filename);
        if (!file.is_open()) {
            cout << "Error opening file: " << filename << endl;
            return 0;
        }

        string line;
        int count = 0;

        // Skip header
        getline(file, line);

        while (getline(file, line)) {
            stringstream ss(line);
            string field;
            Patient p;

            getline(ss, p.id, ',');
            getline(ss, p.name, ',');
            getline(ss, field, ',');
            p.age = stoi(field);
            getline(ss, p.diagnosis, ',');
            getline(ss, p.admissionDate, ',');
            getline(ss, p.phoneNumber, ',');
            getline(ss, p.address);

            // Trim whitespace
            p.id = trim(p.id);
            p.name = trim(p.name);
            p.diagnosis = trim(p.diagnosis);
            p.admissionDate = trim(p.admissionDate);
            p.phoneNumber = trim(p.phoneNumber);
            p.address = trim(p.address);

            insertAtEnd(p);
            count++;
        }

        file.close();
        cout << "\nSuccessfully loaded " << count << " patients from " << filename << endl;
        return count;
    }

    // 14. Save to CSV
    bool saveToCSV(string filename) {
        ofstream file(filename);
        if (!file.is_open()) {
            cout << "Error creating file: " << filename << endl;
            return false;
        }

        // Write header
        file << "ID,Name,Age,Diagnosis,AdmissionDate,PhoneNumber,Address" << endl;

        Node* temp = head;
        while (temp != nullptr) {
            file << temp->data.id << ","
                 << temp->data.name << ","
                 << temp->data.age << ","
                 << temp->data.diagnosis << ","
                 << temp->data.admissionDate << ","
                 << temp->data.phoneNumber << ","
                 << temp->data.address << endl;
            temp = temp->next;
        }

        file.close();
        cout << "Data saved successfully to " << filename << endl;
        return true;
    }

    // 15. Get Count
    int getCount() {
        return nodeCount;
    }

    // 16. Undo Delete
    bool undoDelete() {
        if (undoStack.empty()) {
            cout << "No delete operation to undo!" << endl;
            return false;
        }

        DeletedNode deleted = undoStack.top();
        undoStack.pop();

        if (deleted.position == 0) {
            insertAtBeginning(deleted.data);
        } else {
            insertAtPosition(deleted.data, deleted.position);
        }

        cout << "Undo successful! Patient " << deleted.data.name << " restored." << endl;
        return true;
    }

    // 17. Filter by Diagnosis
    vector<Node*> filterByDiagnosis(string diagnosis) {
        vector<Node*> results;
        string searchDiag = toLower(diagnosis);

        Node* temp = head;
        while (temp != nullptr) {
            if (toLower(temp->data.diagnosis).find(searchDiag) != string::npos) {
                results.push_back(temp);
            }
            temp = temp->next;
        }

        return results;
    }

    // 18. Clear All
    void clearAll() {
        Node* temp = head;
        while (temp != nullptr) {
            Node* next = temp->next;
            delete temp;
            temp = next;
        }
        head = nullptr;
        hashTable.clear();
        while (!undoStack.empty()) {
            undoStack.pop();
        }
        nodeCount = 0;
        cout << "All data cleared." << endl;
    }

    // Generate Sample CSV File
    static void generateSampleCSV(string filename, int numRecords) {
        ofstream file(filename);
        if (!file.is_open()) {
            cout << "Error creating file: " << filename << endl;
            return;
        }

        file << "ID,Name,Age,Diagnosis,AdmissionDate,PhoneNumber,Address" << endl;

        string diagnoses[] = {"Diabetes", "Hypertension", "COVID-19", "Pneumonia", 
                             "Heart Disease", "Cancer", "Fracture", "Asthma", 
                             "Stroke", "Kidney Disease"};
        
        string firstNames[] = {"John", "Jane", "Michael", "Sarah", "David", 
                              "Emily", "Robert", "Lisa", "William", "Mary"};
        
        string lastNames[] = {"Smith", "Johnson", "Williams", "Brown", "Jones", 
                             "Garcia", "Miller", "Davis", "Rodriguez", "Martinez"};

        srand(time(0));

        for (int i = 1; i <= numRecords; i++) {
            string id = "P" + string(5 - to_string(i).length(), '0') + to_string(i);
            string name = firstNames[rand() % 10] + string(" ") + lastNames[rand() % 10];
            int age = 20 + (rand() % 60);
            string diagnosis = diagnoses[rand() % 10];
            
            int year = 2023 + (rand() % 2);
            int month = 1 + (rand() % 12);
            int day = 1 + (rand() % 28);
            string date = to_string(year) + "-" + 
                         (month < 10 ? "0" : "") + to_string(month) + "-" + 
                         (day < 10 ? "0" : "") + to_string(day);
            
            string phone = "+62-8" + to_string(100000000 + rand() % 900000000);
            string address = "Jl. " + lastNames[rand() % 10] + " No. " + to_string(rand() % 100);

            file << id << "," << name << "," << age << "," << diagnosis << "," 
                 << date << "," << phone << "," << address << endl;
        }

        file.close();
        cout << "Sample CSV file with " << numRecords << " records created: " << filename << endl;
    }

    // Display Statistics
    void displayStatistics() {
        if (head == nullptr) {
            cout << "\nNo data available for statistics." << endl;
            return;
        }

        unordered_map<string, int> diagnosisCount;
        int totalAge = 0;
        int minAge = 999, maxAge = 0;

        Node* temp = head;
        while (temp != nullptr) {
            diagnosisCount[temp->data.diagnosis]++;
            totalAge += temp->data.age;
            minAge = min(minAge, temp->data.age);
            maxAge = max(maxAge, temp->data.age);
            temp = temp->next;
        }

        cout << "\n=== STATISTICS ===" << endl;
        cout << "Total Patients: " << nodeCount << endl;
        cout << "Average Age: " << fixed << setprecision(1) << (double)totalAge / nodeCount << endl;
        cout << "Age Range: " << minAge << " - " << maxAge << " years" << endl;
        cout << "\nDiagnosis Distribution:" << endl;
        for (auto& pair : diagnosisCount) {
            cout << "  " << left << setw(20) << pair.first << ": " << pair.second 
                 << " (" << fixed << setprecision(1) << (pair.second * 100.0 / nodeCount) << "%)" << endl;
        }
        cout << endl;
    }
};

// Menu Function
void displayMenu() {
    cout << "\n=== HOSPITAL PATIENT MANAGEMENT SYSTEM ===" << endl;
    cout << "1.  Load Data from CSV" << endl;
    cout << "2.  Insert Patient at Beginning" << endl;
    cout << "3.  Insert Patient at End" << endl;
    cout << "4.  Insert Patient at Position" << endl;
    cout << "5.  Delete from Beginning" << endl;
    cout << "6.  Delete from End" << endl;
    cout << "7.  Delete by ID" << endl;
    cout << "8.  Search by ID" << endl;
    cout << "9.  Search by Name" << endl;
    cout << "10. Update Patient Data" << endl;
    cout << "11. Display All Patients" << endl;
    cout << "12. Sort by Admission Date" << endl;
    cout << "13. Reverse List" << endl;
    cout << "14. Save to CSV" << endl;
    cout << "15. Undo Last Delete" << endl;
    cout << "16. Filter by Diagnosis" << endl;
    cout << "17. Display Statistics" << endl;
    cout << "18. Clear All Data" << endl;
    cout << "19. Generate Sample Data" << endl;
    cout << "0.  Exit" << endl;
    cout << "===========================================" << endl;
    cout << "Enter choice: ";
}

int main() {
    HospitalSystem hospital;
    int choice;
    
    do {
        displayMenu();
        cin >> choice;
        cin.ignore();

        switch (choice) {
            case 1: {
                string filename;
                cout << "Enter CSV filename: ";
                getline(cin, filename);
                hospital.loadFromCSV(filename);
                break;
            }
            case 2: {
                Patient p;
                cout << "Enter Patient ID: "; getline(cin, p.id);
                cout << "Enter Name: "; getline(cin, p.name);
                cout << "Enter Age: "; cin >> p.age; cin.ignore();
                cout << "Enter Diagnosis: "; getline(cin, p.diagnosis);
                cout << "Enter Admission Date (YYYY-MM-DD): "; getline(cin, p.admissionDate);
                cout << "Enter Phone: "; getline(cin, p.phoneNumber);
                cout << "Enter Address: "; getline(cin, p.address);
                hospital.insertAtBeginning(p);
                break;
            }
            case 3: {
                Patient p;
                cout << "Enter Patient ID: "; getline(cin, p.id);
                cout << "Enter Name: "; getline(cin, p.name);
                cout << "Enter Age: "; cin >> p.age; cin.ignore();
                cout << "Enter Diagnosis: "; getline(cin, p.diagnosis);
                cout << "Enter Admission Date (YYYY-MM-DD): "; getline(cin, p.admissionDate);
                cout << "Enter Phone: "; getline(cin, p.phoneNumber);
                cout << "Enter Address: "; getline(cin, p.address);
                hospital.insertAtEnd(p);
                break;
            }
            case 4: {
                Patient p;
                int pos;
                cout << "Enter position: "; cin >> pos; cin.ignore();
                cout << "Enter Patient ID: "; getline(cin, p.id);
                cout << "Enter Name: "; getline(cin, p.name);
                cout << "Enter Age: "; cin >> p.age; cin.ignore();
                cout << "Enter Diagnosis: "; getline(cin, p.diagnosis);
                cout << "Enter Admission Date (YYYY-MM-DD): "; getline(cin, p.admissionDate);
                cout << "Enter Phone: "; getline(cin, p.phoneNumber);
                cout << "Enter Address: "; getline(cin, p.address);
                hospital.insertAtPosition(p, pos);
                break;
            }
            case 5:
                hospital.deleteFromBeginning();
                break;
            case 6:
                hospital.deleteFromEnd();
                break;
            case 7: {
                string id;
                cout << "Enter Patient ID to delete: ";
                getline(cin, id);
                hospital.deleteByID(id);
                break;
            }
            case 8: {
                string id;
                cout << "Enter Patient ID to search: ";
                getline(cin, id);
                Node* result = hospital.searchByID(id);
                if (result) {
                    cout << "\nPatient Found:" << endl;
                    cout << "ID: " << result->data.id << endl;
                    cout << "Name: " << result->data.name << endl;
                    cout << "Age: " << result->data.age << endl;
                    cout << "Diagnosis: " << result->data.diagnosis << endl;
                    cout << "Admission Date: " << result->data.admissionDate << endl;
                    cout << "Phone: " << result->data.phoneNumber << endl;
                    cout << "Address: " << result->data.address << endl;
                } else {
                    cout << "Patient not found!" << endl;
                }
                break;
            }
            case 9: {
                string name;
                cout << "Enter name to search: ";
                getline(cin, name);
                vector<Node*> results = hospital.searchByName(name);
                if (results.empty()) {
                    cout << "No patients found with that name!" << endl;
                } else {
                    cout << "\nFound " << results.size() << " patient(s):" << endl;
                    for (auto node : results) {
                        cout << "ID: " << node->data.id << " | Name: " << node->data.name 
                             << " | Diagnosis: " << node->data.diagnosis << endl;
                    }
                }
                break;
            }
            case 10: {
                string id;
                Patient p;
                cout << "Enter Patient ID to update: ";
                getline(cin, id);
                cout << "Enter new Patient ID: "; getline(cin, p.id);
                cout << "Enter new Name: "; getline(cin, p.name);
                cout << "Enter new Age: "; cin >> p.age; cin.ignore();
                cout << "Enter new Diagnosis: "; getline(cin, p.diagnosis);
                cout << "Enter new Admission Date (YYYY-MM-DD): "; getline(cin, p.admissionDate);
                cout << "Enter new Phone: "; getline(cin, p.phoneNumber);
                cout << "Enter new Address: "; getline(cin, p.address);
                hospital.updatePatientData(id, p);
                break;
            }
            case 11:
                hospital.displayAll();
                break;
            case 12:
                hospital.sortByDate();
                break;
            case 13:
                hospital.reverseList();
                break;
            case 14: {
                string filename;
                cout << "Enter filename to save: ";
                getline(cin, filename);
                hospital.saveToCSV(filename);
                break;
            }
            case 15:
                hospital.undoDelete();
                break;
            case 16: {
                string diagnosis;
                cout << "Enter diagnosis to filter: ";
                getline(cin, diagnosis);
                vector<Node*> results = hospital.filterByDiagnosis(diagnosis);
                if (results.empty()) {
                    cout << "No patients found with that diagnosis!" << endl;
                } else {
                    cout << "\nFound " << results.size() << " patient(s) with " << diagnosis << ":" << endl;
                    for (auto node : results) {
                        cout << "ID: " << node->data.id << " | Name: " << node->data.name 
                             << " | Age: " << node->data.age << endl;
                    }
                }
                break;
            }
            case 17:
                hospital.displayStatistics();
                break;
            case 18:
                hospital.clearAll();
                break;
            case 19: {
                string filename;
                int numRecords;
                cout << "Enter filename for sample data: ";
                getline(cin, filename);
                cout << "Enter number of records to generate (100-10000): ";
                cin >> numRecords;
                HospitalSystem::generateSampleCSV(filename, numRecords);
                break;
            }
            case 0:
                cout << "Exiting system. Thank you!" << endl;
                break;
            default:
                cout << "Invalid choice! Please try again." << endl;
        }
    } while (choice != 0);

    return 0;
}